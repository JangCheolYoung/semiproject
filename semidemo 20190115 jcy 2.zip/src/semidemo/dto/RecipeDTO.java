package semidemo.dto;

public class RecipeDTO {
	private String growth_level;
	private String recipe_title;
	private String main_picture;
	private String ingredient;
	private String r_order;
	private String tip;
	
	public RecipeDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getGrowth_level() {
		return growth_level;
	}

	public void setGrowth_level(String growth_level) {
		this.growth_level = growth_level;
	}

	public String getRecipe_title() {
		return recipe_title;
	}

	public void setRecipe_title(String recipe_title) {
		this.recipe_title = recipe_title;
	}

	public String getMain_picture() {
		return main_picture;
	}

	public void setMain_picture(String main_picture) {
		this.main_picture = main_picture;
	}

	public String getIngredient() {
		return ingredient;
	}

	public void setIngredient(String ingredient) {
		this.ingredient = ingredient;
	}

	public String getR_order() {
		return r_order;
	}

	public void setR_order(String r_order) {
		this.r_order = r_order;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

	
}
